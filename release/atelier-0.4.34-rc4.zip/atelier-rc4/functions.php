<?php
defined( 'ABSPATH' ) || exit;
/** Atelier: modernisme éditorial tactile, HTML explicite et lecture LLM-first. */
add_action( 'after_setup_theme', static function() { add_theme_support( 'title-tag' ); add_theme_support( 'post-thumbnails' ); add_theme_support( 'bbpress' ); add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) ); register_nav_menus( array( 'primary' => __( 'Navigation principale', 'atelier' ) ) ); } );
add_action( 'wp_enqueue_scripts', static function() { $theme_version = wp_get_theme()->get( 'Version' ); $style_file = get_stylesheet_directory() . '/style.css'; $script_file = get_template_directory() . '/assets/js/atelier-interactions.js'; $style_version = file_exists( $style_file ) ? (string) filemtime( $style_file ) : $theme_version; $script_version = file_exists( $script_file ) ? (string) filemtime( $script_file ) : $theme_version; wp_enqueue_style( 'atelier', get_stylesheet_uri(), array(), $style_version ); wp_enqueue_script( 'atelier-interactions', get_template_directory_uri() . '/assets/js/atelier-interactions.js', array(), $script_version, true ); wp_localize_script( 'atelier-interactions', 'atelierSearch', array( 'ajaxUrl' => admin_url( 'admin-ajax.php' ), 'minChars' => 2 ) ); wp_localize_script( 'atelier-interactions', 'atelierCommunity', array( 'ajaxUrl' => admin_url( 'admin-ajax.php' ), 'nonceUrl' => add_query_arg( 'action', 'pfc_community_nonce', admin_url( 'admin-ajax.php' ) ), 'nonce' => wp_create_nonce( 'pfc_community' ), 'loggedIn' => is_user_logged_in() ) ); } );
/** Atelier — les lectures publiques sont cacheables ; les espaces connectés ne le sont jamais. */
add_action( 'send_headers', static function(): void {
	if ( is_user_logged_in() || is_admin() || is_feed() || is_search() || is_404() || is_preview() ) return;
	$is_public_read = is_front_page() || is_home() || is_page() || is_singular( 'topic' ) || is_post_type_archive();
	if ( $is_public_read ) {
		header( 'Cache-Control: public, max-age=300, s-maxage=300, must-revalidate' );
		header( 'Vary: Accept-Encoding' );
	}
} );
add_filter( 'bbp_get_template_stack', static function( array $stack ): array { array_unshift( $stack, trailingslashit( get_stylesheet_directory() ) . 'bbpress/' ); return $stack; } );
function atelier_rank( int $user_id ): string { return (string) get_user_meta( $user_id, 'pfc_rank', true ); }
function atelier_initials( int $user_id ): string { $user = get_userdata( $user_id ); if ( ! $user ) return '–'; $source = trim( $user->first_name . ' ' . $user->last_name ); if ( '' === $source ) $source = $user->display_name; $words = preg_split( '/\s+/', $source ); $letters = ''; foreach ( array_slice( array_filter( $words ), 0, 2 ) as $word ) $letters .= mb_strtoupper( mb_substr( $word, 0, 1 ) ); return $letters ?: mb_strtoupper( mb_substr( $source, 0, 1 ) ); }
function atelier_avatar_color( int $user_id ): string { $colors = array( '#d7e0d4', '#e7d2c6', '#d7d8ea', '#dde4d2', '#e6d8c1' ); return $colors[ $user_id % count( $colors ) ]; }
function atelier_total_upvotes( int $post_id ): int { $legacy = absint( get_post_meta( $post_id, 'pfc_legacy_upvotes_count', true ) ) + absint( get_post_meta( $post_id, 'pfc_native_upvotes_count', true ) ); $native = class_exists( 'PFC_Community' ) ? PFC_Community::native_upvotes( $post_id ) : 0; return $legacy + $native; }
/** Atelier — statistiques publiées : lecture directe des sources bbPress pour résister aux métadonnées de cache historiques. */
function atelier_forum_reply_total( int $forum_id ): int { if ( ! function_exists( 'bbp_get_topic_post_type' ) || ! function_exists( 'bbp_get_topic_reply_count' ) ) return 0; $topic_ids = get_posts( array( 'post_type' => bbp_get_topic_post_type(), 'post_status' => 'publish', 'post_parent' => $forum_id, 'fields' => 'ids', 'posts_per_page' => -1, 'no_found_rows' => true ) ); $count = 0; foreach ( $topic_ids as $topic_id ) $count += (int) bbp_get_topic_reply_count( $topic_id ); return $count; }
function atelier_user_topic_total( int $user_id ): int { return function_exists( 'bbp_get_user_topic_count_raw' ) ? (int) bbp_get_user_topic_count_raw( $user_id ) : 0; }
function atelier_user_reply_total( int $user_id ): int { return function_exists( 'bbp_get_user_reply_count_raw' ) ? (int) bbp_get_user_reply_count_raw( $user_id ) : 0; }
/** Atelier — portail communautaire : statistiques explicites et contributeurs issus des contenus bbPress publiés. */
function atelier_community_stats(): array { global $wpdb; if ( ! function_exists( 'bbp_get_forum_post_type' ) || ! function_exists( 'bbp_get_topic_post_type' ) || ! function_exists( 'bbp_get_reply_post_type' ) ) return array( 'forums' => 0, 'topics' => 0, 'replies' => 0, 'contributors' => 0 ); $forum_type = bbp_get_forum_post_type(); $topic_type = bbp_get_topic_post_type(); $reply_type = bbp_get_reply_post_type(); $rows = $wpdb->get_results( $wpdb->prepare( "SELECT post_type, COUNT(*) AS total FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type IN (%s, %s, %s) GROUP BY post_type", $forum_type, $topic_type, $reply_type ), OBJECT_K ); $authors = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(DISTINCT post_author) FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type IN (%s, %s) AND post_author > 0", $topic_type, $reply_type ) ); return array( 'forums' => isset( $rows[ $forum_type ] ) ? (int) $rows[ $forum_type ]->total : 0, 'topics' => isset( $rows[ $topic_type ] ) ? (int) $rows[ $topic_type ]->total : 0, 'replies' => isset( $rows[ $reply_type ] ) ? (int) $rows[ $reply_type ]->total : 0, 'contributors' => (int) $authors ); }
function atelier_top_contributors( int $limit = 5 ): array { global $wpdb; if ( ! function_exists( 'bbp_get_topic_post_type' ) || ! function_exists( 'bbp_get_reply_post_type' ) ) return array(); $topic_type = bbp_get_topic_post_type(); $reply_type = bbp_get_reply_post_type(); $limit = max( 1, min( 12, $limit ) ); $sql = $wpdb->prepare( "SELECT post_author AS user_id, SUM(CASE WHEN post_type = %s THEN 3 ELSE 1 END) AS score, SUM(CASE WHEN post_type = %s THEN 1 ELSE 0 END) AS topic_total, SUM(CASE WHEN post_type = %s THEN 1 ELSE 0 END) AS reply_total FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type IN (%s, %s) AND post_author > 0 GROUP BY post_author ORDER BY score DESC, MAX(post_date_gmt) DESC LIMIT %d", $topic_type, $topic_type, $reply_type, $topic_type, $reply_type, $limit ); return (array) $wpdb->get_results( $sql ); }
/** Atelier — routes de navigation : le portail reste l’index, les ancres ouvrent des sections réelles et le CTA mène à un formulaire bbPress. */
function atelier_home_section_url( string $section = '' ): string { return home_url( '/' . ( $section ? '#' . ltrim( $section, '#' ) : '' ) ); }
/** Atelier — pages éditoriales réelles : les liens ne reposent plus sur une ancre de home comme destination principale. */
function atelier_page_url( string $slug, string $fallback_section = '' ): string { $page = get_page_by_path( trim( $slug, '/' ), OBJECT, 'page' ); return $page ? (string) get_permalink( $page ) : atelier_home_section_url( $fallback_section ?: $slug ); }
function atelier_discussions_url(): string { return atelier_page_url( 'discussions', 'sources-recentes' ); }
function atelier_spaces_url(): string { return atelier_page_url( 'espaces', 'espaces' ); }
function atelier_methods_url(): string { return atelier_page_url( 'methodes', 'methodes' ); }
function atelier_member_url(): string { return atelier_page_url( 'mon-espace', 'sources-recentes' ); }
function atelier_compose_url(): string { return atelier_discussions_url() . '#new-post'; }
/** Atelier — suggestions : lecture publique uniquement, données publiées, requête nettoyée et volume limité. Aucun nonce n’est utilisé afin de rester compatible avec le cache public. */
add_action( 'wp_ajax_atelier_suggest', 'atelier_ajax_suggest' );
add_action( 'wp_ajax_nopriv_atelier_suggest', 'atelier_ajax_suggest' );
function atelier_ajax_suggest(): void { $query = sanitize_text_field( wp_unslash( $_GET['q'] ?? '' ) ); if ( mb_strlen( $query ) < 2 || ! function_exists( 'bbp_get_topic_post_type' ) || ! function_exists( 'bbp_get_reply_post_type' ) ) wp_send_json_success( array( 'items' => array() ) ); $posts = get_posts( array( 's' => $query, 'post_type' => array( bbp_get_topic_post_type(), bbp_get_reply_post_type() ), 'post_status' => 'publish', 'posts_per_page' => 5, 'orderby' => 'relevance date', 'order' => 'DESC', 'no_found_rows' => true ) ); $items = array(); foreach ( $posts as $post ) { $is_reply = $post->post_type === bbp_get_reply_post_type(); $title = $is_reply ? wp_trim_words( wp_strip_all_tags( $post->post_content ), 12 ) : get_the_title( $post ); $items[] = array( 'title' => $title ?: __( 'Réponse sans titre', 'atelier' ), 'url' => get_permalink( $post ), 'kind' => $is_reply ? __( 'Réponse', 'atelier' ) : __( 'Discussion', 'atelier' ), 'meta' => sprintf( __( '%s · %s', 'atelier' ), get_the_date( 'd.m.Y', $post ), number_format_i18n( atelier_total_upvotes( $post->ID ) ) . ' votes' ) ); } wp_send_json_success( array( 'items' => $items ) ); }
/** Atelier — recherche LLM-first : les résultats publics incluent les deux objets canoniques bbPress. */
add_action( 'pre_get_posts', static function( WP_Query $query ): void { if ( is_admin() || ! $query->is_main_query() || ! $query->is_search() || ! function_exists( 'bbp_get_topic_post_type' ) || ! function_exists( 'bbp_get_reply_post_type' ) ) return; $query->set( 'post_type', array( bbp_get_topic_post_type(), bbp_get_reply_post_type() ) ); } );
/** Atelier — localisation de contenu : les contributions arabes gardent leur script et leur direction sans modifier le HTML canonique. */
function atelier_contains_arabic( string $text ): bool { return (bool) preg_match( '/[\x{0600}-\x{06FF}\x{0750}-\x{077F}\x{08A0}-\x{08FF}]/u', wp_strip_all_tags( $text ) ); }
function atelier_content_dir( string $text ): string { return atelier_contains_arabic( $text ) ? 'rtl' : 'ltr'; }
add_filter( 'body_class', static function( array $classes ): array { if ( is_singular() ) { $post = get_queried_object(); if ( $post instanceof WP_Post && atelier_contains_arabic( (string) $post->post_title . ' ' . (string) $post->post_content ) ) $classes[] = 'atelier-has-arabic'; } return $classes; } );
add_filter( 'language_attributes', static function( string $output ): string { if ( is_singular() ) { $post = get_queried_object(); if ( $post instanceof WP_Post && atelier_contains_arabic( (string) $post->post_title . ' ' . (string) $post->post_content ) ) return 'lang="ar" dir="rtl"'; } return $output; } );
/** Atelier — connexion cohérente avec le site public, y compris lorsque WordPress affiche directement wp-login.php. */

add_action( 'login_enqueue_scripts', static function(): void { $login_file = get_stylesheet_directory() . '/login.css'; $login_version = file_exists( $login_file ) ? (string) filemtime( $login_file ) : wp_get_theme()->get( 'Version' ); wp_enqueue_style( 'atelier-login', get_stylesheet_directory_uri() . '/login.css', array(), $login_version ); } );
add_filter( 'login_headerurl', static function(): string { return home_url( '/' ); } );
add_filter( 'login_headertext', static function(): string { return 'Atelier — Forum de connaissances'; } );
add_filter( 'login_display_language_dropdown', '__return_false' );
add_filter( 'login_message', static function( string $message ): string { $action = sanitize_key( $_REQUEST['action'] ?? '' ); if ( in_array( $action, array( 'register', 'verify', 'resend' ), true ) ) return $message; $register_url = add_query_arg( 'action', 'register', wp_login_url() ); return '<div class="atelier-login-intro"><p class="atelier-kicker">Forum de connaissances</p><h2>Retrouver les conversations qui comptent.</h2><p>Connectez-vous pour répondre, suivre les sujets et retrouver votre archive membre.</p><p class="atelier-login-register"><span>Premier passage ?</span> <a href="' . esc_url( $register_url ) . '">Créer mon accès Atelier <span aria-hidden="true">↗</span></a></p></div>' . $message; } );
add_action( 'login_footer', static function(): void { echo '<p class="atelier-login-back"><a href="' . esc_url( home_url( '/' ) ) . '">← Retourner au forum</a></p>'; } );

/** Atelier — SEO local explicite : descriptions, canonicals et données structurées sans dépendance externe. */
add_action( 'wp_head', static function(): void {
	if ( is_admin() || is_feed() ) { return; }
	$object = get_queried_object();
	$title  = wp_get_document_title();
	$description = '';
	if ( $object instanceof WP_Post ) {
		$description = wp_trim_words( wp_strip_all_tags( (string) $object->post_content ), 28, '…' );
	}
	if ( '' === $description ) { $description = 'Atelier — forum de connaissances et discussions documentées.'; }
	echo '<meta name="description" content="' . esc_attr( $description ) . '" />' . "\n";
	if ( is_singular() || is_page() || is_home() || is_front_page() ) {
		echo '<link rel="canonical" href="' . esc_url( (string) ( is_singular() ? get_permalink() : home_url( add_query_arg( array(), $GLOBALS['wp']->request ?? '' ) ) ) ) . '" />' . "\n";
	}
	if ( is_singular() && function_exists( 'bbp_get_topic_post_type' ) && $object instanceof WP_Post && $object->post_type === bbp_get_topic_post_type() ) {
		$author = get_userdata( (int) $object->post_author );
		$discussion = array(
			'@context' => 'https://schema.org',
			'@type' => 'DiscussionForumPosting',
			'headline' => get_the_title( $object ),
			'url' => get_permalink( $object ),
			'datePublished' => get_post_time( DATE_W3C, true, $object ),
			'articleBody' => wp_strip_all_tags( (string) $object->post_content ),
			'author' => array( '@type' => 'Person', 'name' => $author ? $author->display_name : 'Atelier' ),
		);
		$breadcrumb = array( '@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => array(
			array( '@type' => 'ListItem', 'position' => 1, 'name' => 'Accueil', 'item' => home_url( '/' ) ),
			array( '@type' => 'ListItem', 'position' => 2, 'name' => get_the_title( $object ), 'item' => get_permalink( $object ) ),
		) );
		echo '<script type="application/ld+json">' . wp_json_encode( $discussion, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
		echo '<script type="application/ld+json">' . wp_json_encode( $breadcrumb, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
	}
}, 1 );
